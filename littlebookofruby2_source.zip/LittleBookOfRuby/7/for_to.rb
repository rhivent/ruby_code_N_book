# Ruby Sample program from www.sapphiresteel.com 

for i in 1..10 do
	puts( i )
end

(1..10).each do |i|
	puts(i)
end