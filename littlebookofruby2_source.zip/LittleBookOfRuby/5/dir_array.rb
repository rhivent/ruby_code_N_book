# Ruby Sample program from www.sapphiresteel.com

p( Dir.entries( 'C:\\' ) )