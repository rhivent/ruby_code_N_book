The Little Book Of Ruby
written by
Huw Collingbourne
Copyright � 2008 
SapphireSteel Software 
http://www.sapphiresteel.com
All rights reserved. 

This sample code is provided for use with the free Little Book Of Ruby 
eBook available from: http://www.sapphiresteel.com

You may freely copy and distribute the Little Book Of Ruby eBook and the 
accompanying source code as long as you do not modify the text or remove 
the copyright notice from the eBook. You must not make any charge for the 
eBook or the accompanying source code. 

SapphireSteel Software are the developers of the Ruby In Steel IDE 
for Visual Studio