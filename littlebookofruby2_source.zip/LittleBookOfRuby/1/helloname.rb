# Ruby Sample program from www.sapphiresteel.com

# Here the brackets are optional...
# This works

print('Enter your name: ' )
name = gets()
puts( "Hello #{name}" )

# ...and so does this:

print'Enter your name again: ' 
name = gets
puts "Hello #{name}" 